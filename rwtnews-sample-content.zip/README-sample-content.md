# Red, White and True News Sample Content Import Guide

This guide explains how to import the sample content (3 articles and 2 memes) into the Strapi database for the Red, White and True News website.

## Prerequisites
- Strapi instance running (locally at http://localhost:8080/admin or deployed on DigitalOcean).
- Admin access (username: prof613, email: 852Brown@gmail.com).
- Sample content package (`rwtnews-sample-content.zip`) extracted, containing:
  - `articles.json`
  - `memes.json`
  - `/images/content/2025/June/20/`

## Import Steps
1. **Log into Strapi Admin**:
   - Access at http://localhost:8080/admin or your deployed Strapi URL.
   - Use credentials: `prof613` / `852Brown`.

2. **Upload Images**:
   - Go to “Media Library” > “Upload assets.”
   - Upload images from `/images/content/2025/June/20/`:
     - `economy-growth.jpg`
     - `chart.jpg`
     - `politics-update.jpg`
     - `opinion-piece.jpg`
     - `freedom.jpg`
     - `meme1.jpg`
     - `meme2.jpg`
   - Note image URLs (e.g., `/uploads/2025/June/20/economy-growth.jpg`).

3. **Import Articles**:
   - Go to “Content Manager” > “Article” > “Create new entry.”
   - Manually enter each article from `articles.json`:
     - **Article 1**:
       - Title: Economic Growth Surges in 2025
       - Image: Select `economy-growth.jpg` from Media Library
       - Author: John Smith
       - Category: Economy
       - Secondary Category: US News
       - Date: 2025-06-10
       - Quote: “The U.S. economy is showing remarkable resilience this year.”
       - Body: `<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. <a href="https://example.com">Read the full report</a> for details.</p><img src="/images/content/2025/June/20/chart.jpg" alt="Economic Chart"><p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua...</p>`
       - Slug: economic-growth-2025
       - Is Featured: True
     - **Article 2**:
       - Title: Political Shifts in Washington
       - Image: `politics-update.jpg`
       - Author: Jane Doe
       - Category: Politics
       - Date: 2025-06-09
       - Quote: “New policies are reshaping the political landscape.”
       - Body: `<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit...</p><p>Ut enim ad minim veniam... <a href="https://example.com/news">Learn more</a>.</p>`
       - Slug: political-shifts-2025
     - **Article 3**:
       - Title: Why Freedom Matters
       - Image: `opinion-piece.jpg`
       - Author: Alex Brown
       - Category: Opinion
       - Date: 2025-06-08
       - Quote: “Freedom is the cornerstone of our values.”
       - Body: `<p>Lorem ipsum dolor sit amet... <img src="/images/content/2025/June/20/freedom.jpg" alt="Freedom Symbol"></p><p>Sed do eiusmod tempor...</p>`
       - Slug: why-freedom-matters
   - Save and publish each article.

4. **Import Memes**:
   - Go to “Content Manager” > “Meme” > “Create new entry.”
   - Manually enter each meme from `memes.json`:
     - **Meme 1**:
       - Artist: Cartoonist One
       - Image: `meme1.jpg`
       - Date: 2025-06-10
     - **Meme 2**:
       - Artist: Cartoonist Two
       - Image: `meme2.jpg`
       - Date: 2025-06-09
   - Save and publish each meme.

5. **Verify Content**:
   - Visit https://redwhiteandtruenews.com/ (or localhost:3000).
   - Check:
     - Featured article (Economic Growth) on index.
     - Articles in respective categories (Economy, Politics, Opinion).
     - Memes in sidebar and Meme/Cartoons archive.

## Notes
- Replace placeholder content with real articles/memes in Strapi.
- Images are stored in `/public/images/content/2025/June/20/` for deployment.
- Contact webpagecontact@redwhiteandtruenews.com for support.